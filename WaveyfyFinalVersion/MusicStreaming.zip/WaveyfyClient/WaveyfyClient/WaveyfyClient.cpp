// WaveyfyClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveyfyPlayer.h"


int main()
{
	
	return 0;
}

